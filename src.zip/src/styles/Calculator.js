import React, { useState } from "react";
import { Container, Screen, Prevoius, Current, Button } from './main';
import axios from "axios";
import base_url from "../api/bootapi";

const Calculator = () => {
    const [current, setCurrent] = useState("");
    const [prevoius, setPrevoius] = useState("");
    const [operations, setOperations] = useState("");
    //const [result, setResult] = useState("");

    const appendValueHandler = (el) => {
        console.log("btn click")
        const value = el.target.getAttribute("data");
        if (value === "." && current.includes(".")) return;
        setCurrent(current + value);
    };

    const deleteHandler = () => {
        setCurrent(String(current).slice(0, -1));
    };

    const allclearHandler = () => {
        setCurrent("");
        setOperations("");
        setPrevoius("");
        //  setResult("");
    };


    const chooseOperationHandler = (el) => {
        if (current === "") return;
        if (prevoius !== "") {
            let value = compute();
            setPrevoius(value);
        } else {
            setPrevoius(current);
        }
        setCurrent("");
        setOperations(el.target.getAttribute("data"));
    };

    const equalHandler = () => {
        let value = compute();
        console.log(`value is ${value}`)
        if (value === undefined || value == null) return;
        // setCurrent(value);
        console.log(`value curent ${setCurrent}`)
        setPrevoius("");
        setOperations("");
    };

    const compute = async () => {
       // let result=parseFloat(result1);
       let num1 = parseFloat(prevoius);
       let num2 = parseFloat(current);
       if (isNaN(num1) || isNaN(num2)) return;
       switch (operations) {
           case "÷":        
               const divresult = await axios.get(`${base_url}div/${num1}/${num2}`);
               setCurrent(divresult.data.toString());
               break;

           case "*":
               const mulresult = await axios.get(`${base_url}mul/${num1}/${num2}`);
               setCurrent(mulresult.data.toString());
               break;
           
           case "+":
               const sumresult = await axios.get(`${base_url}sum/${num1}/${num2}`);
               setCurrent(sumresult.data.toString());
               break;
           
           case "-":
              const subresult = await axios.get(`${base_url}sub/${num1}/${num2}`);
               setCurrent(subresult.data.toString());
               break;
           default:
               return;
       }

      // return result;
   };

    //console.log(compute());

    return (
        <>

            <Container>
                <Screen>
                    <Prevoius>{prevoius}{operations}</Prevoius>
                    <Current>{current}</Current>

                </Screen>
                <Button></Button>
                <Button></Button>

                <Button control onClick={allclearHandler}>AC</Button>
                <Button onClick={deleteHandler}>DEL</Button>
                <Button data={9} onClick={appendValueHandler}>9</Button>
                <Button data={8} onClick={appendValueHandler}>8</Button>
                <Button data={7} onClick={appendValueHandler}>7</Button>
                <Button operation data={"+"} onClick={chooseOperationHandler}>+</Button>
                <Button data={6} onClick={appendValueHandler}>6</Button>
                <Button data={5} onClick={appendValueHandler}>5</Button>
                <Button data={4} onClick={appendValueHandler}>4</Button>
                <Button operation data={"-"} onClick={chooseOperationHandler}>-</Button>
                <Button data={3} onClick={appendValueHandler}>3</Button>
                <Button data={2} onClick={appendValueHandler}>2</Button>
                <Button data={1} onClick={appendValueHandler}>1</Button>
                <Button operation data={"*"} onClick={chooseOperationHandler}>*</Button>
                <Button decimal data={"."} onClick={appendValueHandler}>.</Button>
                <Button data={0} onClick={appendValueHandler}>0</Button>
                <Button equals onClick={equalHandler}>=</Button>
                <Button operation data={"÷"} onClick={chooseOperationHandler}>÷</Button>
            </Container>
        </>


    )
}

export default Calculator
