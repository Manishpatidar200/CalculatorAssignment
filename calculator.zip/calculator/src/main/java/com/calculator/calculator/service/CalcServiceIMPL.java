package com.calculator.calculator.service;

import org.springframework.stereotype.Service;

import com.calculator.calculator.bean.Calculator;

@Service
public class CalcServiceIMPL implements CalcService {

	@Override
	public Calculator add(double x, double y) {
		// TODO Auto-generated method stub
		return new Calculator(x,y,x+y) ;
	}

	@Override
	public Calculator subtract(double x, double y) {
		// TODO Auto-generated method stub
		return new Calculator(x,y,x-y);
	}

	@Override
	public Calculator multiply(double x, double y) {
		// TODO Auto-generated method stub
		return new Calculator(x,y,x*y);
	}

	@Override
	public Calculator divide(double x, double y) {
		// TODO Auto-generated method stub
		return new Calculator(x,y,x/y);
	}
	}


